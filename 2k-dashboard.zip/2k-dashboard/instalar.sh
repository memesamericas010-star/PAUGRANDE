#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  2K Dashboard — instalador para VPS (Ubuntu/Debian)
#  Uso:  sudo bash instalar.sh
#  Faz:  Node 22 · dependências · sharp · usuário de serviço · .env ·
#        serviço systemd · impressão digital para ativar a licença.
# ═══════════════════════════════════════════════════════════════════
set -euo pipefail

APP="2k-dashboard"
DIR_APP="/opt/${APP}"
USUARIO="2kbot"
NODE_MAJOR=22

vermelho() { printf '\033[31m%s\033[0m\n' "$*"; }
verde()    { printf '\033[32m%s\033[0m\n' "$*"; }
azul()     { printf '\033[36m%s\033[0m\n' "$*"; }

[ "$(id -u)" -eq 0 ] || { vermelho "Rode como root:  sudo bash instalar.sh"; exit 1; }

azul "── 2K Dashboard · instalação ──────────────────────────────"

# 1) Node.js -----------------------------------------------------------
if ! command -v node >/dev/null 2>&1 || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt "$NODE_MAJOR" ]; then
  azul "Instalando Node.js ${NODE_MAJOR}.x ..."
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash -
  apt-get install -y nodejs
fi
verde "Node $(node -v)"

# sharp precisa destas libs em algumas imagens enxutas
apt-get install -y --no-install-recommends ca-certificates >/dev/null 2>&1 || true

# 2) Usuário de serviço (sem shell de login) ---------------------------
if ! id "$USUARIO" >/dev/null 2>&1; then
  azul "Criando usuário de serviço '${USUARIO}' ..."
  useradd --system --create-home --shell /usr/sbin/nologin "$USUARIO"
fi

# 3) Copiar aplicação --------------------------------------------------
ORIGEM="$(cd "$(dirname "$0")" && pwd)"
azul "Instalando em ${DIR_APP} ..."
mkdir -p "$DIR_APP"
# copia tudo menos o que não deve ir para produção
tar --exclude='./node_modules' --exclude='./.git' --exclude='./data' \
    --exclude='./auth' --exclude='./chaves-autor' --exclude='./.env' \
    -C "$ORIGEM" -cf - . | tar -C "$DIR_APP" -xf -
mkdir -p "$DIR_APP/data" "$DIR_APP/auth"

# 4) Dependências de produção -----------------------------------------
azul "Instalando dependências (npm ci) ..."
cd "$DIR_APP"
if [ -f package-lock.json ]; then npm ci --omit=dev; else npm install --omit=dev; fi

# 5) .env --------------------------------------------------------------
if [ ! -f "$DIR_APP/.env" ]; then
  azul "Criando .env ..."
  cp "$DIR_APP/.env.example" "$DIR_APP/.env"
  TOKEN="$(node -e 'console.log(require("crypto").randomBytes(32).toString("hex"))')"
  sed -i "s|^API_TOKEN=.*|API_TOKEN=${TOKEN}|" "$DIR_APP/.env"
  read -rp "Domínio desta instalação (ex: bot.seudominio.com): " DOM || true
  sed -i "s|^DOMINIO=.*|DOMINIO=${DOM}|" "$DIR_APP/.env"
  verde "API_TOKEN gerado automaticamente e salvo no .env"
fi

chown -R "$USUARIO":"$USUARIO" "$DIR_APP"
chmod 600 "$DIR_APP/.env"

# 6) systemd -----------------------------------------------------------
azul "Registrando serviço systemd ..."
cat > "/etc/systemd/system/${APP}.service" <<UNIT
[Unit]
Description=2K Dashboard
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${USUARIO}
WorkingDirectory=${DIR_APP}
EnvironmentFile=${DIR_APP}/.env
ExecStart=$(command -v node) ${DIR_APP}/server.js
Restart=on-failure
RestartSec=5
# exit 87 = sem licença: não fica reiniciando à toa
RestartPreventExitStatus=87
NoNewPrivileges=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable "${APP}" >/dev/null 2>&1 || true

# 7) Ativação da licença ----------------------------------------------
azul "── Ativação da licença ────────────────────────────────────"
DOMV="$(grep -E '^DOMINIO=' "$DIR_APP/.env" | cut -d= -f2-)"
FP="$(cd "$DIR_APP" && sudo -u "$USUARIO" DOMINIO="$DOMV" node ferramentas/ativar.mjs --dominio "$DOMV" | grep -oE '[0-9A-Z]{5}-[0-9A-Z]{5}-[0-9A-Z]{5}-[0-9A-Z]{5}' || true)"

echo
verde "Impressão digital desta máquina:"
echo
echo "        ${FP}"
echo
echo "1) Envie esse código ao autor para receber sua licenca.key."
echo "2) Salve o arquivo em:   ${DIR_APP}/data/licenca.key"
echo "3) Inicie o serviço:     systemctl start ${APP}"
echo "4) Veja o log:           journalctl -u ${APP} -f"
echo
verde "Instalação concluída."
