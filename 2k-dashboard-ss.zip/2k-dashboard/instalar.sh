#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  2K Dashboard — instalador para VPS (Ubuntu/Debian)
#  Uso:  sudo bash instalar.sh
#  Faz:  Node 22 · dependências · sharp · usuário de serviço · .env ·
#        ATIVAÇÃO ONLINE obrigatória (conexão com o servidor de ativação, com
#        certificado fixado) · licença desta máquina · serviço systemd · start.
#
#  Sem conexão com o servidor de ativação, o serviço NÃO é registrado nem
#  iniciado. Sobrescreva o endereço/PIN pelo ambiente se o autor mandar outro:
#        sudo ATIVACAO_URL=https://IP:PORTA ATIVACAO_PIN=sha256//... bash instalar.sh
# ═══════════════════════════════════════════════════════════════════
set -euo pipefail

APP="2k-dashboard"
DIR_APP="/opt/${APP}"
USUARIO="2kbot"
NODE_MAJOR=22

# Servidor de ativação (o empacotador pode embutir outros valores nestas 2 linhas).
ATIVACAO_URL_PADRAO='https://179.197.231.192:8443'
ATIVACAO_PIN_PADRAO='sha256//yE3VUcbBUPAPIbbvR+j1UogbceKfQvorhq0GoHCV6T8='
ATIVACAO_URL="${ATIVACAO_URL:-$ATIVACAO_URL_PADRAO}"
ATIVACAO_PIN="${ATIVACAO_PIN:-$ATIVACAO_PIN_PADRAO}"
ATIVACAO_TEMPO_MAX="${ATIVACAO_TEMPO_MAX:-0}"   # minutos aguardando aprovação (0 = sem limite)

vermelho() { printf '\033[31m%s\033[0m\n' "$*"; }
verde()    { printf '\033[32m%s\033[0m\n' "$*"; }
azul()     { printf '\033[36m%s\033[0m\n' "$*"; }
amarelo()  { printf '\033[33m%s\033[0m\n' "$*"; }

# Roda um comando como o usuário de serviço, mesmo em imagens sem 'sudo'.
como_usuario() {
  if command -v runuser >/dev/null 2>&1; then runuser -u "$USUARIO" -- "$@"
  elif command -v sudo   >/dev/null 2>&1; then sudo -u "$USUARIO" -- "$@"
  else su -s /bin/sh "$USUARIO" -c "$(printf '%q ' "$@")"; fi
}

# apt sem prompts interativos (dpkg/debconf) para não travar a instalação.
export DEBIAN_FRONTEND=noninteractive

[ "$(id -u)" -eq 0 ] || { vermelho "Rode como root:  sudo bash instalar.sh"; exit 1; }

azul "── 2K Dashboard · instalação ──────────────────────────────"

# 0) Ferramentas de base (imagens enxutas costumam não trazer) -----------
azul "Atualizando índice de pacotes ..."
apt-get update -y >/dev/null 2>&1 || apt-get update -y || true
azul "Garantindo utilitários de base (curl, ca-certificates, tar, xz, gnupg) ..."
apt-get install -y --no-install-recommends \
  curl ca-certificates tar xz-utils gnupg >/dev/null 2>&1 || \
  apt-get install -y --no-install-recommends curl ca-certificates tar xz-utils gnupg || true

# 1) Node.js -----------------------------------------------------------
if ! command -v node >/dev/null 2>&1 || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt "$NODE_MAJOR" ]; then
  azul "Instalando Node.js ${NODE_MAJOR}.x ..."
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash -
  apt-get install -y nodejs
fi
command -v node >/dev/null 2>&1 || { vermelho "Node.js não pôde ser instalado. Verifique a rede/apt e rode de novo."; exit 1; }
verde "Node $(node -v)"

# 2) Usuário de serviço (sem shell de login) ---------------------------
if ! id "$USUARIO" >/dev/null 2>&1; then
  azul "Criando usuário de serviço '${USUARIO}' ..."
  useradd --system --create-home --shell /usr/sbin/nologin "$USUARIO"
fi

# 3) Copiar aplicação --------------------------------------------------
ORIGEM="$(cd "$(dirname "$0")" && pwd)"
azul "Instalando em ${DIR_APP} ..."
mkdir -p "$DIR_APP"
# copia tudo menos o que não deve ir para produção
tar --exclude='./node_modules' --exclude='./.git' --exclude='./data' \
    --exclude='./auth' --exclude='./chaves-autor' --exclude='./.env' \
    -C "$ORIGEM" -cf - . | tar -C "$DIR_APP" -xf -
mkdir -p "$DIR_APP/data" "$DIR_APP/auth"

# 4) Dependências de produção -----------------------------------------
azul "Instalando dependências (npm ci) ..."
cd "$DIR_APP"
if [ -f package-lock.json ]; then
  # se o lock estiver dessincronizado, cai para install em vez de abortar
  npm ci --omit=dev || { amarelo "npm ci falhou; tentando npm install --omit=dev ..."; npm install --omit=dev; }
else
  npm install --omit=dev
fi

# 5) .env --------------------------------------------------------------
if [ ! -f "$DIR_APP/.env" ]; then
  azul "Criando .env ..."
  cp "$DIR_APP/.env.example" "$DIR_APP/.env"
  TOKEN="$(node -e 'console.log(require("crypto").randomBytes(32).toString("hex"))')"
  sed -i "s|^API_TOKEN=.*|API_TOKEN=${TOKEN}|" "$DIR_APP/.env"
  # Domínio: prioriza a variável de ambiente (instalação automática/sem tela).
  # Só pergunta se houver terminal interativo; nunca trava a instalação.
  DOM="${DOMINIO:-}"
  if [ -z "$DOM" ] && [ -t 0 ]; then
    read -rp "Domínio desta instalação (ex: bot.seudominio.com) [Enter p/ pular]: " DOM || true
  fi
  sed -i "s|^DOMINIO=.*|DOMINIO=${DOM}|" "$DIR_APP/.env"
  verde "API_TOKEN gerado automaticamente e salvo no .env"
fi

chown -R "$USUARIO":"$USUARIO" "$DIR_APP"
chmod 600 "$DIR_APP/.env"

# 6) Ativação ONLINE (obrigatória) ------------------------------------
# Camada extra de proteção: antes de registrar/iniciar qualquer coisa, esta
# máquina precisa estabelecer conexão com o servidor de ativação (certificado
# fixado por PIN), registrar o pedido e receber uma licença assinada para ELA.
azul "── Ativação online ────────────────────────────────────────"
DOMV="$(grep -E '^DOMINIO=' "$DIR_APP/.env" | cut -d= -f2- | tr -d "\"' ")"
azul "Enviando pedido de ativação para ${ATIVACAO_URL} e aguardando retorno ..."
# Tenta a ativação; erro 10 (rede/conexão) numa VPS recém-ligada costuma ser
# transitório, então repete algumas vezes antes de desistir.
COD=0
for TENT in 1 2 3 4 5; do
  set +e
  ( cd "$DIR_APP" && como_usuario env DOMINIO="$DOMV" node ferramentas/ativacao.mjs \
      --servidor "$ATIVACAO_URL" --pin "$ATIVACAO_PIN" --dominio "$DOMV" --tempo-max "$ATIVACAO_TEMPO_MAX" )
  COD=$?
  set -e
  # 0 = ok; 11/12/13/14 = falha definitiva (recusa/licença/contrato); só o 10 repete.
  if [ "$COD" -ne 10 ]; then break; fi
  [ "$TENT" -lt 5 ] && { amarelo "Sem conexão com o servidor (tentativa ${TENT}/5). Nova tentativa em 10s ..."; sleep 10; }
done
if [ "$COD" -ne 0 ]; then
  echo
  case "$COD" in
    10) vermelho "Não foi possível estabelecer conexão com o servidor de ativação.";;
    11) vermelho "Pedido de ativação recusado.";;
    12) vermelho "A licença recebida não é válida para esta máquina.";;
    *)  vermelho "Ativação não concluída (código ${COD}).";;
  esac
  vermelho "Por segurança, o serviço NÃO foi registrado nem iniciado."
  echo "   Verifique rede/firewall de saída para ${ATIVACAO_URL} e rode o instalador de novo."
  echo "   (Os arquivos ficaram em ${DIR_APP}; nada roda até a ativação concluir.)"
  exit 1
fi
chmod 600 "$DIR_APP/data/licenca.key" 2>/dev/null || true
chown "$USUARIO":"$USUARIO" "$DIR_APP/data/licenca.key" 2>/dev/null || true

# 7) systemd -----------------------------------------------------------
azul "Registrando serviço systemd ..."
cat > "/etc/systemd/system/${APP}.service" <<UNIT
[Unit]
Description=2K Dashboard
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${USUARIO}
WorkingDirectory=${DIR_APP}
EnvironmentFile=${DIR_APP}/.env
ExecStart=$(command -v node) ${DIR_APP}/server.js
Restart=on-failure
RestartSec=5
# exit 87 = sem licença: não fica reiniciando à toa
RestartPreventExitStatus=87
NoNewPrivileges=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable "${APP}" >/dev/null 2>&1 || true

# 8) Sobe e confere ----------------------------------------------------
azul "Iniciando o serviço ..."
systemctl restart "${APP}" || true
PORTA="$(grep -E '^PORT=' "$DIR_APP/.env" | cut -d= -f2- | tr -d ' ')"; PORTA="${PORTA:-8480}"
OK=0
for _ in $(seq 1 30); do
  if curl -fsk --max-time 3 "http://127.0.0.1:${PORTA}/health" 2>/dev/null | grep -q '"ok"'; then OK=1; break; fi
  sleep 1
done
echo
if [ "$OK" = "1" ]; then
  verde "════════════════════════════════════════════════════════════"
  verde " 2K Dashboard instalado, ativado e RODANDO."
  verde "════════════════════════════════════════════════════════════"
else
  amarelo "Instalado e ativado, mas o serviço ainda não respondeu. Veja o log:"
  echo "   journalctl -u ${APP} -n 40 --no-pager"
fi
echo "   Pasta      : ${DIR_APP}"
echo "   Serviço    : systemctl status ${APP}"
echo "   Logs       : journalctl -u ${APP} -f"
echo
echo "Para atualizar depois: coloque a pasta nova em /opt/${APP}-atualizacoes e rode"
echo "        sudo bash ${DIR_APP}/atualizar.sh      (faz backup do antigo e volta sozinho se falhar)"
echo
verde "Instalação concluída."
